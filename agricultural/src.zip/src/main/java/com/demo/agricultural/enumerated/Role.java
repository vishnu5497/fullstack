package com.demo.agricultural.enumerated;



public enum Role {
    USER, ADMIN;
}