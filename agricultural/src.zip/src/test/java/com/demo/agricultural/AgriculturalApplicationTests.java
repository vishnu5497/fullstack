package com.demo.agricultural;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgriculturalApplicationTests {

	@Test
	void contextLoads() {
	}

}
